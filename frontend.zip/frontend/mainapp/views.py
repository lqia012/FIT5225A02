from django.shortcuts import render, redirect
from django.views.generic.base import TemplateView
from django.views.generic.edit import FormView
from django.http import HttpResponse
from . import forms
import boto3
import requests
import json
import base64


class IndexView(FormView):
    template_name = "login_page.html"
    form_class = forms.LoginForm
    success_url = "/success"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['Message'] = "this is message from index view"
        return context

    def form_valid(self, form):
        return super(IndexView, self).form_valid(form)


def cognito_hosted_ui(request):
    return redirect(
        "https://object-detection.auth.us-east-1.amazoncognito.com/login?client_id=5j1kj4o768u4ji03dpbl0bhcqk&response_type=code&scope=openid&redirect_uri=http://localhost/callback")


def cognito_login_mock(request):
    code = request.GET.get('code')
    context = {}
    if code:
        context['logged_in'] = True
        context['Message'] = "cb success login"
        # return render(request, 'main.html', context=context)
        request.session['logged_in'] = True
        return redirect('get-all-images')
    else:
        context['logged_in'] = False
        context['Message'] = "cb failed login"
        return render(request, 'main.html', context=context)


def cognito_logout(request):
    context = {}
    context['logged_in'] = False
    context['Message'] = "You have logged out."
    request.session['logged_in'] = False
    # return HttpResponse("logged out")
    return redirect('index')


def upload_image(request):
    form = forms.FileUploadForm(request.POST, request.FILES)
    print(request)
    # print(request.FILES)
    # print(request.FILES['file'])
    b64string = base64.b64encode(request.FILES['file'].read())

    print(' ================== ')
    r = requests.post('https://dp53byjgtf.execute-api.us-east-1.amazonaws.com/dev/upload_image?filename={}'.format(request.FILES['file']),
                      headers={
                            #'Content-Type': 'image/jpeg',
                            'isBase64Encoded': 'true'
                            },
                      data=b64string
                      )
    print(r.json())
    return HttpResponse(200)


def upload_image_and_search(request):
    form = forms.FileUploadForm(request.POST, request.FILES)
    print(request)
    # print(request.FILES)
    # print(request.FILES['file'])
    b64string = base64.b64encode(request.FILES['file'].read())

    print(' ================== ')
    r = requests.post('https://dp53byjgtf.execute-api.us-east-1.amazonaws.com/dev/upload_image_and_search?filename={}'.format(request.FILES['file']),
                      headers={
                            #'Content-Type': 'image/jpeg',
                            'isBase64Encoded': 'true'
                            },
                      data=b64string
                      )
    print(r.json())
    context = {'tags': r.json()['tag'], 'items': r.json()['items']}
    return render(request, 'view-result.html', context)


def delete_image(request):
    filename = request.GET.get('filename')
    r = requests.delete('https://dp53byjgtf.execute-api.us-east-1.amazonaws.com/dev/delete_image?filenames={}'.format(filename))
    print(r.json())
    return redirect('/get_all_images')


def get_all_images(request):
    form = forms.FileUploadForm
    context = {"file_upload_form": form}
    r = requests.get("https://dp53byjgtf.execute-api.us-east-1.amazonaws.com/dev/all_images")
    if r.status_code == 200:
        items = r.json()['items']
        for item in items:
            item['url'] = 'https://object-detection-fs.s3.amazonaws.com/upload_images/{}'.format(item['name']['S'])
        context['items'] = items
        return render(request, 'all-images.html', context=context)
    else:
        context['Message'] = "Something went wrong when fetching from DynamoDB"
        return render(request, 'all-images.html', context=context)


def view_one_image(request):
    filename = request.GET.get('filename')
    context = {}
    r = requests.get(
        "https://dp53byjgtf.execute-api.us-east-1.amazonaws.com/dev/get_one_image?filename={}".format(filename))
    if r.status_code == 200:
        item = json.loads(r.json()['item'])
        context['filename'] = filename
        context['img_url'] = 'https://object-detection-fs.s3.amazonaws.com/upload_images/{}'.format(
            item['image_name']['S'])
        context['item'] = item
        tags = item['tags']
        tags_list = []
        for tag in tags['L']:
            for attr in tag:
                print(attr)
            tags_list.append(tag['L'])
        # print(tags_list)
        context['tags'] = tags_list
        # print(item['tags'])
        return render(request, 'one-image.html', context=context)
    else:
        context['Message'] = "Something went wrong when fetching from DynamoDB"
        return render(request, 'all-images.html', context=context)


def remove_tag_from_image(request):
    filename = request.GET.get('filename')
    tag_index = int(request.GET.get('tag_index')) - 1
    r = requests.post(
        'https://dp53byjgtf.execute-api.us-east-1.amazonaws.com/dev/remove_tag_from_image?filename={}&tag_index={}'.format(
            filename, tag_index))
    print(r.json())
    if r.status_code == 200:
        return redirect('view_one_image?filename={}'.format(filename))
    return HttpResponse('Something went wrong and the operation was unsuccessful')
