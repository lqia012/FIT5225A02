from django.urls import path

from . import views

urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('login', views.cognito_hosted_ui, name='login'),
    path('callback', views.cognito_login_mock, name='cognito-cb'),
    path('logout', views.cognito_logout, name='cognito-logout'),
    path('upload_image', views.upload_image, name='upload_image'),
    path('upload_image_and_search', views.upload_image_and_search, name='upload_image_and_search'),
    path('delete_image', views.delete_image, name='delete_image'),
    path('get_all_images', views.get_all_images, name='get-all-images'),
    path('view_one_image', views.view_one_image, name='view-one-image'),
    path('remove_tag_from_image', views.remove_tag_from_image, name='remove_tag_from_image'),
]