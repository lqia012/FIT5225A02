import username as username
from django import forms
from django.core.exceptions import ValidationError
import boto3

cognito_client = boto3.client('cognito-idp', region_name='us-east-1')


class LoginForm(forms.Form):
    username = forms.CharField(max_length=100)
    password = forms.CharField(max_length=24, widget=forms.PasswordInput)

    def clean(self):
        cleaned_data = super().clean()
        cleaned_username = cleaned_data.get('username')
        cleaned_password = cleaned_data.get('password')

        resp = cognito_client.initiate_auth(
            AuthFlow='USER_SRP_AUTH',

        )

        if not (cleaned_username == 'quan' and cleaned_password == '123'):
            raise ValidationError(
                "Failed"
            )


class FileUploadForm(forms.Form):
    file = forms.FileField()




